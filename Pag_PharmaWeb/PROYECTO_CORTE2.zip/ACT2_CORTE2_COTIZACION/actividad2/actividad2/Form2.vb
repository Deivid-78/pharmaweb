﻿Public Class Form2
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.Show()
        Me.Visible = False
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form3.Show()
        Me.Visible = False
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End
    End Sub

    Private Sub chkLectoraDisco_CheckedChanged(sender As Object, e As EventArgs) Handles chkLectoraDisco.CheckedChanged

        gbxLectoraDisco.Enabled = chkLectoraDisco.Checked
    End Sub

    Private Sub chkLectoraCD_CheckedChanged(sender As Object, e As EventArgs) Handles chkLectoraCD.CheckedChanged
        gbxLectoraCD.Enabled = chkLectoraCD.Checked
    End Sub

    Private Sub rbnLectoraDisco1_CheckedChanged(sender As Object, e As EventArgs) Handles rbnLectoraDisco1.CheckedChanged
        txtPrecioLectoraDisco.Text = "3000000"
    End Sub

    Private Sub rbnLectoraDisco2_CheckedChanged(sender As Object, e As EventArgs) Handles rbnLectoraDisco2.CheckedChanged
        txtPrecioLectoraDisco.Text = "4000000"
    End Sub

    Private Sub rbnLectoraDisco3_CheckedChanged(sender As Object, e As EventArgs) Handles rbnLectoraDisco3.CheckedChanged
        txtPrecioLectoraDisco.Text = "6000000"
    End Sub

    Private Sub rbnLectoraCD60X_CheckedChanged(sender As Object, e As EventArgs) Handles rbnLectoraCD60X.CheckedChanged
        txtPrecioLectoraCD.Text = "3500000"
    End Sub

    Private Sub rbnLectoraCD40X_CheckedChanged(sender As Object, e As EventArgs) Handles rbnLectoraCD40X.CheckedChanged
        txtPrecioLectoraCD.Text = "6700000"
    End Sub

    Private Sub rbnLectoraCD80X_CheckedChanged(sender As Object, e As EventArgs) Handles rbnLectoraCD80X.CheckedChanged
        txtPrecioLectoraCD.Text = "4500000"
    End Sub

    Private Sub chkImpresora_CheckedChanged(sender As Object, e As EventArgs) Handles chkImpresora.CheckedChanged
        lstImpresora.Enabled = chkImpresora.Checked
    End Sub

    Private Sub lstImpresora_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstImpresora.SelectedIndexChanged
        Select Case lstImpresora.SelectedIndex
            Case 0
                txtPrecioImpresora.Text = "50000"
            Case 1
                txtPrecioImpresora.Text = "80000"
            Case 2
                txtPrecioImpresora.Text = "140000"
            Case 3
                txtPrecioImpresora.Text = "150000"
        End Select
    End Sub

    Private Sub chkScanner_CheckedChanged(sender As Object, e As EventArgs) Handles chkScanner.CheckedChanged
        lstScanner.Enabled = chkScanner.Checked
    End Sub

    Private Sub lstScanner_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstScanner.SelectedIndexChanged
        Select Case lstScanner.SelectedIndex
            Case 0
                txtPrecioScanner.Text = "60000"
            Case 1
                txtPrecioScanner.Text = "100000"
            Case 2
                txtPrecioScanner.Text = "130000"
            Case 3
                txtPrecioScanner.Text = "170000"
        End Select
    End Sub
End Class