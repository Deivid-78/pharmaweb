﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form3
    Dim i As Integer = 0
    Dim matriz(6, 6) As String
    Dim tel, dire As String



    Private Sub Button3_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button3.Click
        If i < 7 Then
            Dim PrePro, PreMem, PreDis, PreMon, PreTec As Integer
            Dim PreLDi, PreLCD, PreImp, PreSca As Integer
            Dim TotBas, TotAcc, TotVen, TotIGV, TotPag As Single
            PrePro = (Val(Form1.txtPrecioProcesador.Text))
            PreMem = (Val(Form1.txtPrecioMemoria.Text))
            PreDis = (Val(Form1.txtPrecioDisco.Text))
            PreMon = (Val(Form1.txtPrecioMonitor.Text))
            PreTec = (Val(Form1.txtPrecioTeclado.Text))
            PreLDi = (Val(Form2.txtPrecioLectoraDisco.Text))
            PreLCD = (Val(Form2.txtPrecioLectoraCD.Text))
            PreImp = (Val(Form2.txtPrecioImpresora.Text))
            PreSca = (Val(Form2.txtPrecioScanner.Text))
            TotBas = PrePro + PreMem + PreDis + PreMon + PreTec
            TotAcc = PreLDi + PreLCD + PreImp + PreSca
            TotVen = TotBas + TotAcc
            TotIGV = (0.19 * TotVen).ToString
            TotPag = TotVen + TotIGV
            matriz(i, 0) = Form1.TextBoxpedido.Text
            matriz(i, 1) = TextBox1.Text
            matriz(i, 2) = TotBas
            matriz(i, 3) = TotAcc
            matriz(i, 4) = TotVen
            matriz(i, 5) = TotIGV
            matriz(i, 6) = TotPag


            tel = TextBox2.Text
            dire = TextBox3.Text

            i = i + 1
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
        End If

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a, b As Integer
        For a = 0 To 6
            For b = 0 To 6
                DataGridView1.Item(a, b).Value = matriz(b, a)
            Next b
        Next a
        Dim nomb As String
        nomb = matriz(0, 1)
        Label1.Text = $"¡Exelente {nomb}!, tus datos de compra se han registrado con exito."

        Label2.Text = $"Tu numero de telefono registrado es: {tel}" + Environment.NewLine + $"Tu direccion registrada es: {dire}"
        Label5.Text = "Recuerda revisar tus datos registrados, ya que son claves para el envio de tu compra."
        Label3.Text = matriz(0, 6)

    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.Columns.Add("0", "# DE COMPRA")
        DataGridView1.Columns.Add("1", "NOMBRE")
        DataGridView1.Columns.Add("2", "PRECIO TOTAL UTILES ESCOLARES")
        DataGridView1.Columns.Add("3", "PRECIO TOTAL LIBROS")
        DataGridView1.Columns.Add("4", "SUBTOTAL VENTA")
        DataGridView1.Columns.Add("5", "SUBTOTAL IVA(19%)")

        DataGridView1.Columns.Add("6", "TOTAL COMPRA")
        DataGridView1.Rows.Add(6)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form4.Show()
        Me.Visible = False

    End Sub


End Class