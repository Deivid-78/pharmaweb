﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form4
    Dim i As Integer = 0
    Dim matriz(5, 5) As String

    Dim f As Integer = 0
    Dim matriz1(5, 5) As String

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim a, b As Integer
        For a = 0 To 5
            For b = 0 To 5
                DataGridView1.Item(a, b).Value = matriz(b, a)
            Next b
        Next

    End Sub

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.Columns.Add("0", "ID_Alumno")
        DataGridView1.Columns.Add("1", "NOMBRE")
        DataGridView1.Columns.Add("2", "TELEFONO")
        DataGridView1.Columns.Add("3", "GENERO")
        DataGridView1.Columns.Add("4", "CURSO")

        DataGridView1.Columns.Add("5", "MATERIA")
        DataGridView1.Rows.Add(5)

        DataGridView2.Columns.Add("0", "ID_DOCENTE")
        DataGridView2.Columns.Add("1", "NOMBRE")
        DataGridView2.Columns.Add("2", "TELEFONO")
        DataGridView2.Columns.Add("3", "ESPECIALIZACION")
        DataGridView2.Columns.Add("4", "MATERIA QUE DICTA")

        DataGridView2.Columns.Add("5", "SALON AL QUE DICTA")
        DataGridView2.Rows.Add(5)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If i < 6 Then

            matriz(i, 0) = TextBox1.Text
            matriz(i, 1) = TextBox2.Text
            matriz(i, 2) = TextBox3.Text
            matriz(i, 3) = TextBox4.Text
            matriz(i, 4) = TextBox5.Text
            matriz(i, 5) = TextBox6.Text

            i = i + 1
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
            TextBox5.Text = ""
            TextBox6.Text = ""
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If i < 6 Then

            matriz1(f, 0) = TextBox7.Text
            matriz1(f, 1) = TextBox8.Text
            matriz1(f, 2) = TextBox9.Text
            matriz1(f, 3) = TextBox10.Text
            matriz1(f, 4) = TextBox11.Text
            matriz1(f, 5) = TextBox12.Text

            f = f + 1
            TextBox7.Text = ""
            TextBox8.Text = ""
            TextBox9.Text = ""
            TextBox10.Text = ""
            TextBox11.Text = ""
            TextBox12.Text = ""
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim a, b As Integer
        For a = 0 To 5
            For b = 0 To 5
                DataGridView2.Item(a, b).Value = matriz1(b, a)
            Next b
        Next
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        End
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Form3.Show()
        Me.Visible = False
    End Sub
End Class