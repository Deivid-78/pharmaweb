﻿Public Class Form1
    Private Sub cboProcesador_SelectedIndexChanged_1(sender As Object, e As EventArgs) Handles cboProcesador.SelectedIndexChanged
        Select Case cboProcesador.SelectedIndex
            Case 0
                txtPrecioProcesador.Text = "150000"
            Case 1
                txtPrecioProcesador.Text = "250000"
            Case 2
                txtPrecioProcesador.Text = "320000"
            Case 3
                txtPrecioProcesador.Text = "400000"
        End Select
    End Sub

    Private Sub lstMemoria_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstMemoria.SelectedIndexChanged
        Select Case lstMemoria.SelectedIndex
            Case 0
                txtPrecioMemoria.Text = "250000"
            Case 1
                txtPrecioMemoria.Text = "310000"
            Case 2
                txtPrecioMemoria.Text = "360000"
            Case 3
                txtPrecioMemoria.Text = "420000"
        End Select
    End Sub

    Private Sub lstDisco_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstDisco.SelectedIndexChanged
        Select Case lstDisco.SelectedIndex
            Case 0
                txtPrecioDisco.Text = "100000"
            Case 1
                txtPrecioDisco.Text = "200000"
            Case 2
                txtPrecioDisco.Text = "280000"
            Case 3
                txtPrecioDisco.Text = "320000"
        End Select
    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        txtPrecioMonitor.Text = "250000"
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        txtPrecioTeclado.Text = "100000"
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        txtPrecioTeclado.Text = "150000"
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        txtPrecioMonitor.Text = "200000"
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form2.Show()
        Me.Visible = False
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form3.Show()
        Me.Visible = False
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End

    End Sub
End Class
