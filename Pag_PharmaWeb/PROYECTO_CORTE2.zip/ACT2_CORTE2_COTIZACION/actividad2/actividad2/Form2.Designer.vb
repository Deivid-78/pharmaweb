﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txtPrecioScanner = New System.Windows.Forms.TextBox()
        Me.txtPrecioImpresora = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lstScanner = New System.Windows.Forms.ListBox()
        Me.lstImpresora = New System.Windows.Forms.ListBox()
        Me.chkScanner = New System.Windows.Forms.CheckBox()
        Me.chkImpresora = New System.Windows.Forms.CheckBox()
        Me.txtPrecioLectoraCD = New System.Windows.Forms.TextBox()
        Me.txtPrecioLectoraDisco = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.gbxLectoraCD = New System.Windows.Forms.GroupBox()
        Me.rbnLectoraCD80X = New System.Windows.Forms.RadioButton()
        Me.rbnLectoraCD60X = New System.Windows.Forms.RadioButton()
        Me.rbnLectoraCD40X = New System.Windows.Forms.RadioButton()
        Me.gbxLectoraDisco = New System.Windows.Forms.GroupBox()
        Me.rbnLectoraDisco3 = New System.Windows.Forms.RadioButton()
        Me.rbnLectoraDisco1 = New System.Windows.Forms.RadioButton()
        Me.rbnLectoraDisco2 = New System.Windows.Forms.RadioButton()
        Me.chkLectoraCD = New System.Windows.Forms.CheckBox()
        Me.chkLectoraDisco = New System.Windows.Forms.CheckBox()
        Me.TabControl1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.gbxLectoraCD.SuspendLayout()
        Me.gbxLectoraDisco.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(53, 6)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(531, 621)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.Button3)
        Me.TabPage2.Controls.Add(Me.Button2)
        Me.TabPage2.Controls.Add(Me.Button1)
        Me.TabPage2.Controls.Add(Me.txtPrecioScanner)
        Me.TabPage2.Controls.Add(Me.txtPrecioImpresora)
        Me.TabPage2.Controls.Add(Me.Label12)
        Me.TabPage2.Controls.Add(Me.Label11)
        Me.TabPage2.Controls.Add(Me.lstScanner)
        Me.TabPage2.Controls.Add(Me.lstImpresora)
        Me.TabPage2.Controls.Add(Me.chkScanner)
        Me.TabPage2.Controls.Add(Me.chkImpresora)
        Me.TabPage2.Controls.Add(Me.txtPrecioLectoraCD)
        Me.TabPage2.Controls.Add(Me.txtPrecioLectoraDisco)
        Me.TabPage2.Controls.Add(Me.Label10)
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Controls.Add(Me.gbxLectoraCD)
        Me.TabPage2.Controls.Add(Me.gbxLectoraDisco)
        Me.TabPage2.Controls.Add(Me.chkLectoraCD)
        Me.TabPage2.Controls.Add(Me.chkLectoraDisco)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3, 3, 3, 3)
        Me.TabPage2.Size = New System.Drawing.Size(523, 595)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Accesorios"
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button3.Location = New System.Drawing.Point(373, 531)
        Me.Button3.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(74, 45)
        Me.Button3.TabIndex = 18
        Me.Button3.Text = "SALIR"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button2.Location = New System.Drawing.Point(94, 531)
        Me.Button2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(94, 45)
        Me.Button2.TabIndex = 17
        Me.Button2.Text = "COTIZACION"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(218, 531)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(113, 45)
        Me.Button1.TabIndex = 16
        Me.Button1.Text = "UTILES ESCOLARES"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'txtPrecioScanner
        '
        Me.txtPrecioScanner.Location = New System.Drawing.Point(338, 465)
        Me.txtPrecioScanner.Name = "txtPrecioScanner"
        Me.txtPrecioScanner.Size = New System.Drawing.Size(120, 20)
        Me.txtPrecioScanner.TabIndex = 15
        '
        'txtPrecioImpresora
        '
        Me.txtPrecioImpresora.Location = New System.Drawing.Point(79, 465)
        Me.txtPrecioImpresora.Name = "txtPrecioImpresora"
        Me.txtPrecioImpresora.Size = New System.Drawing.Size(120, 20)
        Me.txtPrecioImpresora.TabIndex = 14
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(358, 423)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(94, 13)
        Me.Label12.TabIndex = 13
        Me.Label12.Text = "Precio Libro Ingles"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(86, 423)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(110, 13)
        Me.Label11.TabIndex = 12
        Me.Label11.Text = "Precio Libro Literatura"
        '
        'lstScanner
        '
        Me.lstScanner.FormattingEnabled = True
        Me.lstScanner.Items.AddRange(New Object() {"Benigger I", "Benigger II", "Benigger III"})
        Me.lstScanner.Location = New System.Drawing.Point(338, 355)
        Me.lstScanner.Name = "lstScanner"
        Me.lstScanner.Size = New System.Drawing.Size(120, 17)
        Me.lstScanner.TabIndex = 11
        '
        'lstImpresora
        '
        Me.lstImpresora.FormattingEnabled = True
        Me.lstImpresora.Items.AddRange(New Object() {"Don Quijote", "El Principito", "La Odisea"})
        Me.lstImpresora.Location = New System.Drawing.Point(79, 355)
        Me.lstImpresora.Name = "lstImpresora"
        Me.lstImpresora.Size = New System.Drawing.Size(120, 17)
        Me.lstImpresora.TabIndex = 10
        '
        'chkScanner
        '
        Me.chkScanner.AutoSize = True
        Me.chkScanner.Location = New System.Drawing.Point(365, 314)
        Me.chkScanner.Name = "chkScanner"
        Me.chkScanner.Size = New System.Drawing.Size(54, 17)
        Me.chkScanner.TabIndex = 9
        Me.chkScanner.Text = "Ingles"
        Me.chkScanner.UseVisualStyleBackColor = True
        '
        'chkImpresora
        '
        Me.chkImpresora.AutoSize = True
        Me.chkImpresora.Location = New System.Drawing.Point(106, 314)
        Me.chkImpresora.Name = "chkImpresora"
        Me.chkImpresora.Size = New System.Drawing.Size(70, 17)
        Me.chkImpresora.TabIndex = 8
        Me.chkImpresora.Text = "Literatura"
        Me.chkImpresora.UseVisualStyleBackColor = True
        '
        'txtPrecioLectoraCD
        '
        Me.txtPrecioLectoraCD.Location = New System.Drawing.Point(339, 262)
        Me.txtPrecioLectoraCD.Name = "txtPrecioLectoraCD"
        Me.txtPrecioLectoraCD.Size = New System.Drawing.Size(120, 20)
        Me.txtPrecioLectoraCD.TabIndex = 7
        '
        'txtPrecioLectoraDisco
        '
        Me.txtPrecioLectoraDisco.Location = New System.Drawing.Point(79, 262)
        Me.txtPrecioLectoraDisco.Name = "txtPrecioLectoraDisco"
        Me.txtPrecioLectoraDisco.Size = New System.Drawing.Size(120, 20)
        Me.txtPrecioLectoraDisco.TabIndex = 6
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(336, 218)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(126, 13)
        Me.Label10.TabIndex = 5
        Me.Label10.Text = "Precio Libro Matematicas"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(86, 218)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(106, 13)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "Precio Libro Sociales"
        '
        'gbxLectoraCD
        '
        Me.gbxLectoraCD.Controls.Add(Me.rbnLectoraCD80X)
        Me.gbxLectoraCD.Controls.Add(Me.rbnLectoraCD60X)
        Me.gbxLectoraCD.Controls.Add(Me.rbnLectoraCD40X)
        Me.gbxLectoraCD.Location = New System.Drawing.Point(338, 70)
        Me.gbxLectoraCD.Name = "gbxLectoraCD"
        Me.gbxLectoraCD.Size = New System.Drawing.Size(120, 128)
        Me.gbxLectoraCD.TabIndex = 3
        Me.gbxLectoraCD.TabStop = False
        Me.gbxLectoraCD.Text = "Generacion"
        '
        'rbnLectoraCD80X
        '
        Me.rbnLectoraCD80X.AutoSize = True
        Me.rbnLectoraCD80X.Location = New System.Drawing.Point(16, 92)
        Me.rbnLectoraCD80X.Name = "rbnLectoraCD80X"
        Me.rbnLectoraCD80X.Size = New System.Drawing.Size(98, 17)
        Me.rbnLectoraCD80X.TabIndex = 2
        Me.rbnLectoraCD80X.TabStop = True
        Me.rbnLectoraCD80X.Text = "Calculo Integral"
        Me.rbnLectoraCD80X.UseVisualStyleBackColor = True
        '
        'rbnLectoraCD60X
        '
        Me.rbnLectoraCD60X.AutoSize = True
        Me.rbnLectoraCD60X.Location = New System.Drawing.Point(15, 33)
        Me.rbnLectoraCD60X.Name = "rbnLectoraCD60X"
        Me.rbnLectoraCD60X.Size = New System.Drawing.Size(94, 17)
        Me.rbnLectoraCD60X.TabIndex = 1
        Me.rbnLectoraCD60X.TabStop = True
        Me.rbnLectoraCD60X.Text = "Algebra Baldor"
        Me.rbnLectoraCD60X.UseVisualStyleBackColor = True
        '
        'rbnLectoraCD40X
        '
        Me.rbnLectoraCD40X.AutoSize = True
        Me.rbnLectoraCD40X.Location = New System.Drawing.Point(16, 60)
        Me.rbnLectoraCD40X.Name = "rbnLectoraCD40X"
        Me.rbnLectoraCD40X.Size = New System.Drawing.Size(84, 17)
        Me.rbnLectoraCD40X.TabIndex = 0
        Me.rbnLectoraCD40X.TabStop = True
        Me.rbnLectoraCD40X.Text = "Aritemtica XI"
        Me.rbnLectoraCD40X.UseVisualStyleBackColor = True
        '
        'gbxLectoraDisco
        '
        Me.gbxLectoraDisco.Controls.Add(Me.rbnLectoraDisco3)
        Me.gbxLectoraDisco.Controls.Add(Me.rbnLectoraDisco1)
        Me.gbxLectoraDisco.Controls.Add(Me.rbnLectoraDisco2)
        Me.gbxLectoraDisco.Location = New System.Drawing.Point(79, 70)
        Me.gbxLectoraDisco.Name = "gbxLectoraDisco"
        Me.gbxLectoraDisco.Size = New System.Drawing.Size(120, 128)
        Me.gbxLectoraDisco.TabIndex = 2
        Me.gbxLectoraDisco.TabStop = False
        Me.gbxLectoraDisco.Text = "Generacion "
        '
        'rbnLectoraDisco3
        '
        Me.rbnLectoraDisco3.AutoSize = True
        Me.rbnLectoraDisco3.Location = New System.Drawing.Point(16, 92)
        Me.rbnLectoraDisco3.Name = "rbnLectoraDisco3"
        Me.rbnLectoraDisco3.Size = New System.Drawing.Size(99, 17)
        Me.rbnLectoraDisco3.TabIndex = 6
        Me.rbnLectoraDisco3.TabStop = True
        Me.rbnLectoraDisco3.Text = "Dialogos Platon"
        Me.rbnLectoraDisco3.UseVisualStyleBackColor = True
        '
        'rbnLectoraDisco1
        '
        Me.rbnLectoraDisco1.AutoSize = True
        Me.rbnLectoraDisco1.Location = New System.Drawing.Point(16, 33)
        Me.rbnLectoraDisco1.Name = "rbnLectoraDisco1"
        Me.rbnLectoraDisco1.Size = New System.Drawing.Size(60, 17)
        Me.rbnLectoraDisco1.TabIndex = 4
        Me.rbnLectoraDisco1.TabStop = True
        Me.rbnLectoraDisco1.Text = "El Atlas"
        Me.rbnLectoraDisco1.UseVisualStyleBackColor = True
        '
        'rbnLectoraDisco2
        '
        Me.rbnLectoraDisco2.AutoSize = True
        Me.rbnLectoraDisco2.Location = New System.Drawing.Point(16, 60)
        Me.rbnLectoraDisco2.Name = "rbnLectoraDisco2"
        Me.rbnLectoraDisco2.Size = New System.Drawing.Size(83, 17)
        Me.rbnLectoraDisco2.TabIndex = 5
        Me.rbnLectoraDisco2.TabStop = True
        Me.rbnLectoraDisco2.Text = "Constitucion"
        Me.rbnLectoraDisco2.UseVisualStyleBackColor = True
        '
        'chkLectoraCD
        '
        Me.chkLectoraCD.AutoSize = True
        Me.chkLectoraCD.Location = New System.Drawing.Point(360, 36)
        Me.chkLectoraCD.Name = "chkLectoraCD"
        Me.chkLectoraCD.Size = New System.Drawing.Size(86, 17)
        Me.chkLectoraCD.TabIndex = 1
        Me.chkLectoraCD.Text = "Matematicas"
        Me.chkLectoraCD.UseVisualStyleBackColor = True
        '
        'chkLectoraDisco
        '
        Me.chkLectoraDisco.AutoSize = True
        Me.chkLectoraDisco.Location = New System.Drawing.Point(94, 36)
        Me.chkLectoraDisco.Name = "chkLectoraDisco"
        Me.chkLectoraDisco.Size = New System.Drawing.Size(109, 17)
        Me.chkLectoraDisco.TabIndex = 0
        Me.chkLectoraDisco.Text = "Ciencias Sociales"
        Me.chkLectoraDisco.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(669, 609)
        Me.Controls.Add(Me.TabControl1)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.gbxLectoraCD.ResumeLayout(False)
        Me.gbxLectoraCD.PerformLayout()
        Me.gbxLectoraDisco.ResumeLayout(False)
        Me.gbxLectoraDisco.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents txtPrecioScanner As TextBox
    Friend WithEvents txtPrecioImpresora As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents lstScanner As ListBox
    Friend WithEvents lstImpresora As ListBox
    Friend WithEvents chkScanner As CheckBox
    Friend WithEvents chkImpresora As CheckBox
    Friend WithEvents txtPrecioLectoraCD As TextBox
    Friend WithEvents txtPrecioLectoraDisco As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents gbxLectoraCD As GroupBox
    Friend WithEvents rbnLectoraCD80X As RadioButton
    Friend WithEvents rbnLectoraCD60X As RadioButton
    Friend WithEvents rbnLectoraCD40X As RadioButton
    Friend WithEvents gbxLectoraDisco As GroupBox
    Friend WithEvents rbnLectoraDisco3 As RadioButton
    Friend WithEvents rbnLectoraDisco1 As RadioButton
    Friend WithEvents rbnLectoraDisco2 As RadioButton
    Friend WithEvents chkLectoraCD As CheckBox
    Friend WithEvents chkLectoraDisco As CheckBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
End Class
