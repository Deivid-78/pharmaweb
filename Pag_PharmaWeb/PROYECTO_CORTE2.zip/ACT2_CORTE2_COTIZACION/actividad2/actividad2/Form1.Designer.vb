﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.rbnMonitor14 = New System.Windows.Forms.RadioButton()
        Me.rbnMonitor15 = New System.Windows.Forms.RadioButton()
        Me.rbnTecladoSimple = New System.Windows.Forms.RadioButton()
        Me.rbnTecladoLujo = New System.Windows.Forms.RadioButton()
        Me.rbnLectoraDisco2 = New System.Windows.Forms.RadioButton()
        Me.rbnLectoraDisco1 = New System.Windows.Forms.RadioButton()
        Me.rbnLectoraDisco3 = New System.Windows.Forms.RadioButton()
        Me.rbnLectoraCD40X = New System.Windows.Forms.RadioButton()
        Me.rbnLectoraCD60X = New System.Windows.Forms.RadioButton()
        Me.rbnLectoraCD80X = New System.Windows.Forms.RadioButton()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TextBoxpedido = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txtPrecioTeclado = New System.Windows.Forms.TextBox()
        Me.txtPrecioMonitor = New System.Windows.Forms.TextBox()
        Me.txtPrecioDisco = New System.Windows.Forms.TextBox()
        Me.txtPrecioMemoria = New System.Windows.Forms.TextBox()
        Me.txtPrecioProcesador = New System.Windows.Forms.TextBox()
        Me.cboProcesador = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.lstDisco = New System.Windows.Forms.ListBox()
        Me.lstMemoria = New System.Windows.Forms.ListBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'rbnMonitor14
        '
        Me.rbnMonitor14.AutoSize = True
        Me.rbnMonitor14.Location = New System.Drawing.Point(8, 23)
        Me.rbnMonitor14.Margin = New System.Windows.Forms.Padding(4)
        Me.rbnMonitor14.Name = "rbnMonitor14"
        Me.rbnMonitor14.Size = New System.Drawing.Size(54, 20)
        Me.rbnMonitor14.TabIndex = 0
        Me.rbnMonitor14.TabStop = True
        Me.rbnMonitor14.Text = "LCD"
        Me.rbnMonitor14.UseVisualStyleBackColor = True
        '
        'rbnMonitor15
        '
        Me.rbnMonitor15.AutoSize = True
        Me.rbnMonitor15.Location = New System.Drawing.Point(8, 57)
        Me.rbnMonitor15.Margin = New System.Windows.Forms.Padding(4)
        Me.rbnMonitor15.Name = "rbnMonitor15"
        Me.rbnMonitor15.Size = New System.Drawing.Size(64, 20)
        Me.rbnMonitor15.TabIndex = 13
        Me.rbnMonitor15.TabStop = True
        Me.rbnMonitor15.Text = "OLED"
        Me.rbnMonitor15.UseVisualStyleBackColor = True
        '
        'rbnTecladoSimple
        '
        Me.rbnTecladoSimple.AutoSize = True
        Me.rbnTecladoSimple.Location = New System.Drawing.Point(20, 23)
        Me.rbnTecladoSimple.Margin = New System.Windows.Forms.Padding(4)
        Me.rbnTecladoSimple.Name = "rbnTecladoSimple"
        Me.rbnTecladoSimple.Size = New System.Drawing.Size(101, 20)
        Me.rbnTecladoSimple.TabIndex = 0
        Me.rbnTecladoSimple.TabStop = True
        Me.rbnTecladoSimple.Text = "Ergonomico"
        Me.rbnTecladoSimple.UseVisualStyleBackColor = True
        '
        'rbnTecladoLujo
        '
        Me.rbnTecladoLujo.AutoSize = True
        Me.rbnTecladoLujo.Location = New System.Drawing.Point(20, 57)
        Me.rbnTecladoLujo.Margin = New System.Windows.Forms.Padding(4)
        Me.rbnTecladoLujo.Name = "rbnTecladoLujo"
        Me.rbnTecladoLujo.Size = New System.Drawing.Size(69, 20)
        Me.rbnTecladoLujo.TabIndex = 1
        Me.rbnTecladoLujo.TabStop = True
        Me.rbnTecladoLujo.Text = "Gamer"
        Me.rbnTecladoLujo.UseVisualStyleBackColor = True
        '
        'rbnLectoraDisco2
        '
        Me.rbnLectoraDisco2.AutoSize = True
        Me.rbnLectoraDisco2.Location = New System.Drawing.Point(21, 74)
        Me.rbnLectoraDisco2.Margin = New System.Windows.Forms.Padding(4)
        Me.rbnLectoraDisco2.Name = "rbnLectoraDisco2"
        Me.rbnLectoraDisco2.Size = New System.Drawing.Size(106, 20)
        Me.rbnLectoraDisco2.TabIndex = 5
        Me.rbnLectoraDisco2.TabStop = True
        Me.rbnLectoraDisco2.Text = "PlayStation 4"
        Me.rbnLectoraDisco2.UseVisualStyleBackColor = True
        '
        'rbnLectoraDisco1
        '
        Me.rbnLectoraDisco1.AutoSize = True
        Me.rbnLectoraDisco1.Location = New System.Drawing.Point(21, 41)
        Me.rbnLectoraDisco1.Margin = New System.Windows.Forms.Padding(4)
        Me.rbnLectoraDisco1.Name = "rbnLectoraDisco1"
        Me.rbnLectoraDisco1.Size = New System.Drawing.Size(106, 20)
        Me.rbnLectoraDisco1.TabIndex = 4
        Me.rbnLectoraDisco1.TabStop = True
        Me.rbnLectoraDisco1.Text = "PlayStation 3"
        Me.rbnLectoraDisco1.UseVisualStyleBackColor = True
        '
        'rbnLectoraDisco3
        '
        Me.rbnLectoraDisco3.AutoSize = True
        Me.rbnLectoraDisco3.Location = New System.Drawing.Point(21, 113)
        Me.rbnLectoraDisco3.Margin = New System.Windows.Forms.Padding(4)
        Me.rbnLectoraDisco3.Name = "rbnLectoraDisco3"
        Me.rbnLectoraDisco3.Size = New System.Drawing.Size(106, 20)
        Me.rbnLectoraDisco3.TabIndex = 6
        Me.rbnLectoraDisco3.TabStop = True
        Me.rbnLectoraDisco3.Text = "PlayStation 5"
        Me.rbnLectoraDisco3.UseVisualStyleBackColor = True
        '
        'rbnLectoraCD40X
        '
        Me.rbnLectoraCD40X.AutoSize = True
        Me.rbnLectoraCD40X.Location = New System.Drawing.Point(29, 74)
        Me.rbnLectoraCD40X.Margin = New System.Windows.Forms.Padding(4)
        Me.rbnLectoraCD40X.Name = "rbnLectoraCD40X"
        Me.rbnLectoraCD40X.Size = New System.Drawing.Size(105, 20)
        Me.rbnLectoraCD40X.TabIndex = 0
        Me.rbnLectoraCD40X.TabStop = True
        Me.rbnLectoraCD40X.Text = "Xbox Serie S"
        Me.rbnLectoraCD40X.UseVisualStyleBackColor = True
        '
        'rbnLectoraCD60X
        '
        Me.rbnLectoraCD60X.AutoSize = True
        Me.rbnLectoraCD60X.Location = New System.Drawing.Point(29, 41)
        Me.rbnLectoraCD60X.Margin = New System.Windows.Forms.Padding(4)
        Me.rbnLectoraCD60X.Name = "rbnLectoraCD60X"
        Me.rbnLectoraCD60X.Size = New System.Drawing.Size(86, 20)
        Me.rbnLectoraCD60X.TabIndex = 1
        Me.rbnLectoraCD60X.TabStop = True
        Me.rbnLectoraCD60X.Text = "Xbox One"
        Me.rbnLectoraCD60X.UseVisualStyleBackColor = True
        '
        'rbnLectoraCD80X
        '
        Me.rbnLectoraCD80X.AutoSize = True
        Me.rbnLectoraCD80X.Location = New System.Drawing.Point(29, 113)
        Me.rbnLectoraCD80X.Margin = New System.Windows.Forms.Padding(4)
        Me.rbnLectoraCD80X.Name = "rbnLectoraCD80X"
        Me.rbnLectoraCD80X.Size = New System.Drawing.Size(104, 20)
        Me.rbnLectoraCD80X.TabIndex = 2
        Me.rbnLectoraCD80X.TabStop = True
        Me.rbnLectoraCD80X.Text = "Xbox Serie X"
        Me.rbnLectoraCD80X.UseVisualStyleBackColor = True
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.DarkSalmon
        Me.TabPage1.Controls.Add(Me.Label12)
        Me.TabPage1.Controls.Add(Me.Label11)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.TextBoxpedido)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.Button3)
        Me.TabPage1.Controls.Add(Me.Button2)
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Controls.Add(Me.txtPrecioTeclado)
        Me.TabPage1.Controls.Add(Me.txtPrecioMonitor)
        Me.TabPage1.Controls.Add(Me.txtPrecioDisco)
        Me.TabPage1.Controls.Add(Me.txtPrecioMemoria)
        Me.TabPage1.Controls.Add(Me.txtPrecioProcesador)
        Me.TabPage1.Controls.Add(Me.cboProcesador)
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Controls.Add(Me.lstDisco)
        Me.TabPage1.Controls.Add(Me.lstMemoria)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3, 3, 3, 3)
        Me.TabPage1.Size = New System.Drawing.Size(446, 595)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Configuracion Basica"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft YaHei UI", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Brown
        Me.Label10.Location = New System.Drawing.Point(16, 18)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(420, 19)
        Me.Label10.TabIndex = 23
        Me.Label10.Text = "BIENVENIDO A LA PAGINA DE COMPRA DE UTILES ESCOLARES"
        '
        'TextBoxpedido
        '
        Me.TextBoxpedido.Location = New System.Drawing.Point(250, 86)
        Me.TextBoxpedido.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.TextBoxpedido.Name = "TextBoxpedido"
        Me.TextBoxpedido.Size = New System.Drawing.Size(128, 20)
        Me.TextBoxpedido.TabIndex = 22
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(72, 87)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(168, 15)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "Digitanos tu # de pedido:"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(333, 547)
        Me.Button3.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(67, 27)
        Me.Button3.TabIndex = 20
        Me.Button3.Text = "SALIR"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(179, 547)
        Me.Button2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(86, 27)
        Me.Button2.TabIndex = 19
        Me.Button2.Text = "COTIZACION"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(44, 547)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(78, 27)
        Me.Button1.TabIndex = 18
        Me.Button1.Text = "LIBROS"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txtPrecioTeclado
        '
        Me.txtPrecioTeclado.Location = New System.Drawing.Point(273, 496)
        Me.txtPrecioTeclado.Name = "txtPrecioTeclado"
        Me.txtPrecioTeclado.Size = New System.Drawing.Size(127, 20)
        Me.txtPrecioTeclado.TabIndex = 17
        '
        'txtPrecioMonitor
        '
        Me.txtPrecioMonitor.Location = New System.Drawing.Point(54, 496)
        Me.txtPrecioMonitor.Name = "txtPrecioMonitor"
        Me.txtPrecioMonitor.Size = New System.Drawing.Size(120, 20)
        Me.txtPrecioMonitor.TabIndex = 16
        '
        'txtPrecioDisco
        '
        Me.txtPrecioDisco.Location = New System.Drawing.Point(290, 323)
        Me.txtPrecioDisco.Name = "txtPrecioDisco"
        Me.txtPrecioDisco.Size = New System.Drawing.Size(100, 20)
        Me.txtPrecioDisco.TabIndex = 15
        '
        'txtPrecioMemoria
        '
        Me.txtPrecioMemoria.Location = New System.Drawing.Point(64, 323)
        Me.txtPrecioMemoria.Name = "txtPrecioMemoria"
        Me.txtPrecioMemoria.Size = New System.Drawing.Size(100, 20)
        Me.txtPrecioMemoria.TabIndex = 14
        '
        'txtPrecioProcesador
        '
        Me.txtPrecioProcesador.Location = New System.Drawing.Point(290, 158)
        Me.txtPrecioProcesador.Name = "txtPrecioProcesador"
        Me.txtPrecioProcesador.Size = New System.Drawing.Size(100, 20)
        Me.txtPrecioProcesador.TabIndex = 13
        '
        'cboProcesador
        '
        Me.cboProcesador.FormattingEnabled = True
        Me.cboProcesador.Items.AddRange(New Object() {"Cuadriculado", "Rayado", "Milimetrado", "Liso"})
        Me.cboProcesador.Location = New System.Drawing.Point(54, 157)
        Me.cboProcesador.Name = "cboProcesador"
        Me.cboProcesador.Size = New System.Drawing.Size(121, 21)
        Me.cboProcesador.TabIndex = 12
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.RadioButton1)
        Me.GroupBox2.Controls.Add(Me.RadioButton2)
        Me.GroupBox2.Location = New System.Drawing.Point(273, 374)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(127, 81)
        Me.GroupBox2.TabIndex = 11
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Tipo de Borrador"
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(15, 46)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(48, 17)
        Me.RadioButton1.TabIndex = 1
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Nata"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(15, 19)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(85, 17)
        Me.RadioButton2.TabIndex = 0
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Miga de Pan"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RadioButton3)
        Me.GroupBox1.Controls.Add(Me.RadioButton4)
        Me.GroupBox1.Location = New System.Drawing.Point(54, 374)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(120, 81)
        Me.GroupBox1.TabIndex = 10
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Tipo de Tijeras"
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Location = New System.Drawing.Point(6, 46)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(76, 17)
        Me.RadioButton3.TabIndex = 13
        Me.RadioButton3.TabStop = True
        Me.RadioButton3.Text = "Punta Fina"
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.Location = New System.Drawing.Point(6, 19)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(84, 17)
        Me.RadioButton4.TabIndex = 0
        Me.RadioButton4.TabStop = True
        Me.RadioButton4.Text = "Punta Roma"
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'lstDisco
        '
        Me.lstDisco.FormattingEnabled = True
        Me.lstDisco.Items.AddRange(New Object() {"Lápis de grafito", "Lápis de Crayón", "Lápis de grasa"})
        Me.lstDisco.Location = New System.Drawing.Point(273, 236)
        Me.lstDisco.Name = "lstDisco"
        Me.lstDisco.Size = New System.Drawing.Size(138, 17)
        Me.lstDisco.TabIndex = 9
        '
        'lstMemoria
        '
        Me.lstMemoria.FormattingEnabled = True
        Me.lstMemoria.Items.AddRange(New Object() {"Retráctiles- De Aceite", "Punta fina- De Gel", "Multi tinta- De  Líquida"})
        Me.lstMemoria.Location = New System.Drawing.Point(44, 236)
        Me.lstMemoria.Name = "lstMemoria"
        Me.lstMemoria.Size = New System.Drawing.Size(152, 17)
        Me.lstMemoria.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(299, 469)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(80, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Precio Borrador"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(78, 469)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(66, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Precio Tijera"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(299, 286)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(82, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Precio del Lapiz"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(72, 296)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(87, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Precio del Esfero"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(316, 202)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Lapices"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(97, 202)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Esferos"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(296, 125)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(86, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Precio Cuaderno"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(72, 125)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Tipo de Cuaderno"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Location = New System.Drawing.Point(34, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(454, 621)
        Me.TabControl1.TabIndex = 1
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(150, 55)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(0, 13)
        Me.Label11.TabIndex = 24
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft YaHei UI", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Brown
        Me.Label12.Location = New System.Drawing.Point(149, 49)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(137, 19)
        Me.Label12.TabIndex = 25
        Me.Label12.Text = "DEL COLEGIO C.N.C"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDark
        Me.ClientSize = New System.Drawing.Size(539, 609)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents rbnMonitor14 As RadioButton
    Friend WithEvents rbnMonitor15 As RadioButton
    Friend WithEvents rbnTecladoSimple As RadioButton
    Friend WithEvents rbnTecladoLujo As RadioButton
    Friend WithEvents rbnLectoraDisco2 As RadioButton
    Friend WithEvents rbnLectoraDisco1 As RadioButton
    Friend WithEvents rbnLectoraDisco3 As RadioButton
    Friend WithEvents rbnLectoraCD40X As RadioButton
    Friend WithEvents rbnLectoraCD60X As RadioButton
    Friend WithEvents rbnLectoraCD80X As RadioButton
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents txtPrecioTeclado As TextBox
    Friend WithEvents txtPrecioMonitor As TextBox
    Friend WithEvents txtPrecioDisco As TextBox
    Friend WithEvents txtPrecioMemoria As TextBox
    Friend WithEvents txtPrecioProcesador As TextBox
    Friend WithEvents cboProcesador As ComboBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents RadioButton3 As RadioButton
    Friend WithEvents RadioButton4 As RadioButton
    Friend WithEvents lstDisco As ListBox
    Friend WithEvents lstMemoria As ListBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents TextBoxpedido As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
End Class
